<?php error_reporting(0);?> 
<!DOCTYPE html>
    <html ng-app="ionicApp"> 
      <head>              
             <meta charset="UTF-8" content="text/html">
              <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1 , user-scalable=no">
              <title> Words Ai </title>
              
 <link href="css/ionic.min.css" rel="stylesheet">              
 <link href="css/bootstrap.min.css" rel="stylesheet"> 
 <link href="css/ai.css" rel="stylesheet"> 

 <script src="js/ionic.bundle.min.js"></script>     

      </head>