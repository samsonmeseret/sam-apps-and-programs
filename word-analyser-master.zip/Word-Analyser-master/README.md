# Word-Analyser
Words Ai is a full functioning tool to analyse words and characters in a given text 
